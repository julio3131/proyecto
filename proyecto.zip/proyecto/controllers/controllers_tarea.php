<?php
    require_once("../models/modelo.php");
    $services = new Service();
    $datos = $services->getTareas();
    require_once("../views/vista.php");
?>