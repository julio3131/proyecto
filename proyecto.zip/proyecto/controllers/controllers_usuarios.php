<?php
    require_once("../models/modelo_usuarios.php");
    $services = new Service();
    $datos = $services->getUsuarios();
    require_once("../views/vista_usuarios.php");
?>