<!DOCTYPE html>
<?php
if ((isset($_POST['tarea'])) && ($_POST['tarea'] != '') && (isset($_POST['descripcion'])) && ($_POST['descripcion'] != '' && (isset($_POST['fecha'])) && ($_POST['fecha'] != '') && (isset($_POST['prioridad'])) && ($_POST['prioridad'] != '') && (isset($_POST['usuario'])) && ($_POST['usuario'] != '')) {

    include "models/modelo_tarea.php";
    $nuevo = new Service();
    $asd = $nuevo->setTareas($_POST['tarea'], $_POST['descripcion'], $_POST['fecha'], $_POST['prioridad']), $_POST['usuario'];
}
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Ejemplo MVC con PHP</title>
        <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" >
        <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
        <script type="text/javascript" src="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
    </head>
    <body>
        <div class="container">
            <header class="text-center">
                <h1>proyecto</h1>
                <hr/>
                <p class="lead">tareas</p>
            </header>
            <div class="row">
                <div class="col-lg-6">

                    <form action="#" method="post" class="col-lg-5">
                        <h3>tarea</h3>                
                        Tarea: <input type="text" name="tarea" class="form-control"/>    
                        Descripcion: <input type="text" name="descripcion" class="form-control"/>    
                        Fecha: <input type="text" name="fecha" class="form-control"/>    
                        Prioridad: <input type="text" name="prioridad" class="form-control"/>    
                        Usuario: <input type="text" name="usuario" class="form-control"/>   
                        <br/>
                        <input type="submit" value="Crear" class="btn btn-success"/>
                    </form>
                </div>
                <div class="col-lg-6 text-center">
                    <hr/>
                    <h3>lista de tareas</h3>
                    <a href="controllers/controllers.php"><i class="fa fa-align-justify"></i> Acceder al listado de servicios</a>
                    <hr/>
                </div> 
            </div>
        
        </div>
    </body>
</html>