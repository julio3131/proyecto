<?php

class Service {
    
    private $servicio;
    private $db;

    public function __construct() {
        $this->servicio = array();
        $this->db = new PDO('mysql:host=localhost;dbname=Proyecto', "root", "");
    }

    private function setTarea() {
        return $this->db->query("SET Tareas 'utf8'");
    }


    public function getTareas(){

        self::setNames();
        $sql = "SELECT id, tarea, descripcion,fecha,prioridad,usuario FROM tareas";
        foreach ((array) $this->db->query($sql) as $res) {
            $this->tareas[] = $res;
        }
        return $this->tareas;
        $this->db = null;
    }

    public function setTareas($tarea, $descripcion,$fecha,$prioridad,$usuario) {

        self::setNames();
        $sql = "INSERT INTO tareas(tarea,descripcion,fecha, prioridad,usuario) VALUES ('" . $tarea . "', '" . $descripcion . "' '" . $fecha . "' '" . $prioridad . "' '" . $usuario . "')";
        $result = $this->db->query($sql);

        if ($result) {
            return true;
        } else {
            return false;
        }
    }
}
?>