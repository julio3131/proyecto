<?php

class Service {
    
    private $usuarios;
    private $db;

    public function __construct() {
        $this->usuarios = array();
        $this->db = new PDO('mysql:host=localhost;dbname=Proyecto', "root", "");
    }

    private function setUsuario() {
        return $this->db->query("SET Usuarios 'utf8'");
    }


    public function getUsuarios(){

        self::setUsuario();
        $sql = "SELECT id, nombre, contrasena, tipo FROM usuarios";
        foreach ((array) $this->db->query($sql) as $res) {
            $this->tareas[] = $res;
        }
        return $this->tareas;
        $this->db = null;
    }

    public function setUsuarios($nombre, $contrasena,$tipo) {

        self::setUsuario();
        $sql = "INSERT INTO usuarios(nombre, contrasena,tipo) VALUES (" . $nombre . "', '" . $contrasena . "', '" . $tipo . "')";
        $result = $this->db->query($sql);

        if ($result) {
            return true;
        } else {
            return false;
        }
    }
}
?>