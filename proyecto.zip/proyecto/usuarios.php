<!DOCTYPE html>
<?php
if ((isset($_POST['nombre'])) && ($_POST['nombre'] != '') && (isset($_POST['contrasena'])) && ($_POST['contrasena'] != '') && (isset($_POST['tipo'])) && ($_POST['tipo'] != '')) {

    include "models/modelo_usuarios.php";
    $nuevo = new Service();
    $asd = $nuevo->setUsuarios($_POST['nombre'], $_POST['contrasena'],$_POST['tipo']);
}
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>usuarios</title>
        <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" >
        <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
        <script type="text/javascript" src="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
    </head>
    <body>
        <div class="container">
            <header class="text-center">
                <h1>proyecto</h1>
                <hr/>
                <p class="lead">usuario</p>
            </header>
            <div class="row">
                <div class="col-lg-6">

                    <form action="#" method="post" class="col-lg-5">
                        <h3>usuario</h3>                
                        usuario: <input type="text" name="nombre" class="form-control"/>    
                        contrasena: <input type="text" name="contrasena" class="form-control"/>    
                        tipo: <input type="text" name="tipo" class="form-control"/>    
                         
                        <br/>
                        <input type="submit" value="Crear" class="btn btn-success"/>
                    </form>
                </div>
                <div class="col-lg-6 text-center">
                    <hr/>
                    <h3>lista de tareas</h3>
                    <a href="controllers/controllers_usuarios.php"><i class="fa fa-align-justify"></i> Acceder al listado de servicios</a>
                    <hr/>
                </div> 
            </div>
        
        </div>
    </body>
</html>